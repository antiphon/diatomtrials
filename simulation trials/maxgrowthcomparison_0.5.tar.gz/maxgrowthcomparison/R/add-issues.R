# Add challenges to a curve

#' Add independent Gaussian noise to a series
#'
#' @param obs x,y matrix
#' @param sigma Gaussian noise sd
#' @param truncate truncate to >=0?
#' @param log add the noise at log scale? returns in normal scale
#' @param log1 if log=TRUE, sample noise with mean -sigma^2/2 to have expectation = 1
#' @export
add_noise <- function(obs, sigma = 0.4, truncate = TRUE, log = FALSE, log1 = TRUE, ...) {
  mu <- if(log & log1) -sigma^2/2 else 0
  e <- rnorm(nrow(obs), mu, sigma)
  y <- obs[,2]
  if(log) y <- log(y)
  y <- y + e
  if(log) y <- exp(y) # back
  if(truncate) y <- pmax(y, 0)
  obs[,2] <-y
  obs
}

# Add challenges to a curve

#' Add independent Laplace noise to a series
#'
#' @param obs x,y matrix
#' @param sigma Laplace diversity
#' @param truncate truncate to >=0?
#' @param log add the noise at log scale? returns in normal scale
#' @export
add_noise_laplace <- function(obs, sigma = 0.4, truncate = TRUE, log = FALSE, ...) {
  n <- nrow(obs)
  e <- rexp(n, 1/sigma) - rexp(n, 1/sigma)
  y <- obs[,2]
  if(log) y <- log(y)
  y <- y + e
  if(log) y <- exp(y) # back
  if(truncate) y <- pmax(y, 0)
  obs[,2] <-y
  obs
}



#' Add AR1 Noise To a Series
#'
#' @param obs x,y matrix
#' @param sigma Gaussian noise sd
#' @param rho Autocorrelation parameter
#' @param truncate truncate to >=0?
#' @param log add the noise at log scale? returns in normal scale
#' @param log1 if log=TRUE, sample noise with mean -sigma^2/2 to have expectation = 1
#' @export
add_AR1_noise <- function(obs, sigma = 0.4, rho = 0.1, truncate = TRUE,
                          log = FALSE, log1 = TRUE, ...) {
  mu <- if(log & log1) -sigma^2/2 else 0
  e <- rnorm(nrow(obs), mu, sigma)
  y <- obs[,2]
  if(log) y <- log(y)
  u <- e * 0
  u[1] <- e[1]
  for(i in 2:nrow(obs)) u[i] <- u[i-1] * rho + e[i]
  y <- y + u
  if(log) y <- exp(y) # back
  if(truncate) y <- pmax(y, 0)
  obs[,2] <-y
  obs
}


#' Add a 'death' event
#'
#' @param obs x,y matrix, x = time, y = value
#' @param lag time point for the crash
#' @param rate speed of downfall
#' @details uses square-exponential curve with negative rate, normalised to 0-1, to emulate survival,
#' and the result is the product of the observed curve with the survival curve .
#' @export
add_crash <- function(obs, at = 7, rate = 1, ...) {
  #surv <- model_logistic(obs[,1], c(rate=-rate, lag=at, max = 1))
  x <- obs[,1]
  r <- x - at
  r[x <= at] <- 0
  surv <- exp(-r^2*rate/2)
  obs[,2] <- obs[,2] * surv
  obs
}

#' Right censor ie drop values after some time
#'
#' @param obs x,y matrix, x = time, y = value
#' @param at last time point to keep
#' @param drop if TRUE drop tail, if FALSE replace y with NA
#' @export
add_trunc <- function(obs, at = 5, ..., drop = FALSE) {
  if(drop)
    obs <- obs[obs[,1] < at,]
  else
    obs[obs[,1]>=at, 2] <- NA

  obs
}

#' Add a small starting value
#'
#' @param obs x,y matrix, x = time, y = value
#' @param a the value to add to y
#' @param ulimits alternatively, sample a from unif(ulimits)
#' @export
add_nugget <- function(obs, a = 0, ulimits){
  if(!missing(ulimits)) a <- runif(1, ulimits[1], ulimits[2])
  obs[,2] <- obs[,2] + a
  obs
}

#' Sparsify the series
#'
#' @param obs x,y matrix, x = time, y = value
#' @param prec precentage to keep.
#' @param by alternative to prec: keep only each by'th
#' @export

add_sparse <- function(obs, prec = .3, by = NULL, ...) {
  n <- nrow(obs)
  if(is.null(by)){
    m <- n * prec
    by <- ceiling(n/m)
  }
  obs[seq(1, n, by = by),]
}

#' List of all problems
#' @export
problems <- list(noise = add_noise,
                 noise_laplace = add_noise_laplace,
                 crash = add_crash, truncation = add_trunc, sparse = add_sparse)
