#' curve RSS
#'
#' @param x times
#' @param y value at times x
#' @param predictor function to predict y from x
#' @export
curve_rss <- function(x, y, predictor) {
  #model <- attr(fit, "model")
  #modelf <- get(paste0("model_", model))
  ypred <- predictor(x)
  sum((y-ypred)^2)
}

#' RSS and AIC for a model
#'
#' @param x times
#' @param y value at times x
#' @param fit fitted curve model parameters
#' @export

curve_metrics  <- function(x, y, model_fit) {
  model <- attr(model_fit, "model")
  modelf <- get(paste0("model_", model))
  predictor <- function(x) modelf(x, model_fit)
  rss <- curve_rss(x, y, predictor)
  aic <- rss * length(y) + 2 * length(model_fit)
  data.frame(AIC=aic, RSS=rss, n = length(y), p = length(model_fit))
}


