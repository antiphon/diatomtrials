# Non-parametric curve estimates



###########################
# Non-parametric ones. No generic parametrisation.
#

smooth_loess <- function(x, fit) {
  predict(fit, x)
}

smooth_spline <- function(x, fit) {
  predict(fit, x)
}

