#' Logistic curve
#'
#' @param x time coordinates
#' @param params rate lag high
#' @param ... ignored
#' @details params: rate lag maximum
#' @export
model_logistic <- function(x, params, ...) {
  rate <- params[1]
  lag <- params[2]
  A <- params[3]
  A / (1 + exp(4*rate/A*(lag - x) + 2))
}

#' Gompertz  curve
#'
#' @param x time coordinates
#' @param params rate lag high
#' @param ... ignored
#' @details params: rate lag maximum
#' @export
model_gompertz <- function(x, params) {
  rate <- params[1]
  lag <- params[2]
  A <- params[3]
  A * exp( -exp(rate * exp(1)/A * (lag - x) + 1)  )
}

#' Richard's curve
#'
#' @param x time coordinates
#' @param params rate lag high shape
#' @param ... ignored
#' @details params: rate lag maximum shape
#' @export
model_richards <- function(x, params){
  rate <- params[1]
  lag <- params[2]
  A <- params[3]
  nu <- params[4]
  A * (1 + nu * exp(1 + nu + rate/A*(1+nu)^(1+1/nu) * (lag - x) )    )^(-1/nu)
}


#' Peleg's curve
#'
#' Logistic growth + logistic death.
#'
#' @param x time coordinates
#' @param params rate lag high -rate -lag
#' @param ... ignored
#' @details params: rate lag high -rate -lag
#' @export
model_peleg <- function(x, params){
  model_logistic(x, params[1:3]) * model_logistic(x, c(params[4:5], 1))
}


#' Weibull curve
#'
#' Weibull growth model, no real lag. Has a lower asymptote
#'
#' @param x time coordinates
#' @param params rate lag high
#' @param ... ignored
#' @details the 'lag' here tweaks the inflection,
#'
#' inflection = (1/rate) ((lag-1) / lag)^(1/lag)
#'
#' there is no 'sigmoidal' lag. If rate = 1, we have the simple exponential growth curve.
#'
#' @export
model_weibull <- function(x, params){
  rate <- params[1]
  lag  <- params[2]
  A    <- params[3]
  A - exp(-(rate*x)^lag)
}


#' Janoschek's curve
#'
#' Similar to Weibull, but easier to fit.
#'
#' @param x time coordinates
#' @param params rate lag high
#' @param ... ignored
#' @details params: rate lag high. the 'lag' here tweaks the inflection,
#' there is no 'sigmoidal' lag.
#'
#' @export
model_janoschek <- function(x, params){
  rate <- params[1]
  lag  <- params[2]
  A    <- params[3]
  A - exp(-rate * x^lag) # only difference is rate not ^lag
}

#' Morgan-Mercer-Flodin curve
#'
#'
#'
#' @param x time coordinates
#' @param params rate lag high
#' @param ... ignored
#' @details params: rate lag high.
#'
#' @export
model_mmf <- function(x, params){
  rate <- params[1]
  lag  <- params[2]
  A    <- params[3]
  A - 1 / (1 +  (rate*x)^lag) # only difference is rate not ^lag
}

#' The von Bertalanffy curve
#'
#' Most used in some circles.
#'
#' @param x time coordinates
#' @param params rate lag high
#' @param ... ignored
#' @details params: rate lag high. lag equals time 0 value here.
#'
#' @export
model_bertalanffy <- function(x, params){
  rate <- params[1]
  lag  <- params[2]
  A    <- params[3]
  A * ( 1- exp(-rate*(x-lag))) # only difference is rate not ^lag
}



#' Baranyi curve
#'
#' Stationary and homogeneous solution to the Baranyi and Roberts 1995 model.
#'
#' @param x time coordinates
#' @param params rate lag high low
#' @param ... ignored
#' @details params: rate lag high low. low is the starting value (x=0).
#'
#' @export
model_baranyi <- function(x, params){
  rate <- params[1]
  lag  <- params[2]
  A    <- params[3] # for consistency in this package
  y0   <- params[4]
  h0   <- lag * rate
  B    <- x + 1/rate * log( exp(-rate * x) + exp(-h0) - exp(-rate * x - h0))
  ly   <- log(y0) + rate * B - log( 1 + ( exp(rate * B) - 1) / exp(log(A)- log(y0))  )
  exp(ly)
}



#' List of all curve models
#'
#' @export
curve_models <- list(Logistic = model_logistic,
                     Gompertz = model_gompertz,
                     Richards = model_richards,
                     Peleg    = model_peleg,
                     Weibull  = model_weibull,
                     Janoschek= model_janoschek,
                     MMF      = model_mmf,
                     Bertanlaffy = model_bertalanffy,
                     Baranyi  = model_baranyi
                     )




#' nls fit a curve model to series
#'
#' @param x time grid
#' @param y values at time grid
#' @param model curve model
#' @param aug add zero points for peleg estimation
#' @param logscale optimise |log(y)-log(f(x))| instead of |y - f(x)|
#' @param start optional, passed to nsl.lm
#' @param upper optional, passed to nsl.lm
#' @param lower optional, passed to nsl.lm
#' @param nugget if TRUE, estimate a random positive shift at x=0, i.e. y(0) = eps.
#'
#' @details Uses minpack.lm::nls.lm to optimise. Note baranyi always has a positive nugget.
#'
#' @importFrom minpack.lm nls.lm
#' @export
curve_fit <- function(x, y,
                      model = "logistic",
                      aug = FALSE,
                      logscale = FALSE,
                      start, upper, lower,
                      nugget = FALSE) {
  # match
  i <- pmatch(tolower(model), ok <- tolower(names(curve_models)))
  if(is.na(i)) stop(paste0("Model not identified. Supports: ", paste0(ok, collapse=", ")) )
  model <- ok[i]

  if(model == "baranyi") nugget <- FALSE

  # start from zero
  x <- x - x[1]
  y0 <- y
  y0r <- range(y0)
  yr <- range(y)
  xr <- range(x)
  delta <- diff(yr) * 0.001 # tiny addition to logs
  if(nugget) y <- y - min(y) + delta
  modelf <- get(paste0("model_", model))
  opres <- function(params) y - modelf(x, params)
  if(nugget) opres  <- function(params) y - (modelf(x, params[-1]) + params[1])
  # baranyi includes nugget as last parameter
  ## in case optising in logscale, like multiplicative error
  if(logscale) {
    opres <-            function(params) log(y + delta) - log( modelf(x, params ) + delta)
    if(nugget) opres <- function(params) log(y + delta) - log( modelf(x, params[-1]) + delta + params[1])
  }

  #
  # initials
  rate0 <- max(diff(y))
  lag0 <- 0.1 * diff(xr)
  A0 <- diff(yr)
  lowr <- c(0.0001 * rate0, 0, mean(y))
  uppr <- c(100 * rate0, max(x), 1000*max(y))
  strt <- c(rate0, lag0, A0)
  parnames <- c("rate", "lag", "A")
  ## specific
  if(model == "richards") {
    lowr <- c(lowr, 0.00001)
    uppr <- c(uppr, 100)
    strt <- c(strt, 1)
    parnames <- c(parnames, "shape")
  }
  else if(model == "peleg") {
    lowr <- c(lowr, -rate0 *   1000, min(x))
    uppr <- c(uppr, rate0 * 0.001, max(x) * 2)
    strt <- c(strt, 0, max(x) * 1.5 )
    parnames <- c(parnames, "rate2", "lag2")
    if(aug) {
      x <- c(x, max(x) + 1:5 * median(diff(x)))
      y <- c(y, rep(0, 5))
    }
  }
  else if(model == "baranyi") {
    strt <- c(strt, max(delta, y0r[1]))
    parnames <- c(parnames, "low")
    lowr <- c(lowr, 0.00001)
    uppr <- c(uppr, y0r[2])

  }
  # in case a nugget is wanted.
  if(nugget){
    strt <- c(0, strt)
    v <- c(0,1) * A0/2
    #browser()
    lowr <- c(v[1], lowr)
    uppr <- c(v[2], uppr)
    y <- y0
  }
  if(missing(start)) start <- strt
  if(missing(upper)) upper <- uppr
  if(missing(lower)) lower <- lowr

  # optimise
  ff <- nls.lm(par = start,
               lower = lower,
               upper = upper,
               fn  = opres,
               control=list(maxiter=1000) )
  # gather
  w <- c(ff$par)
  ## nugget?
  shift <- 0
  if(nugget){
    shift <- w[1]
    w <- w[-1]
  }
  names(w) <- parnames
  attr(w, "model") <- model
  attr(w, "deviance") <- ff$deviance
  attr(w, "nugget") <- ifelse(nugget, shift, 0)
  attr(w, "logscale") <- logscale
  # done
  w
}



#' Predict with a curve model
#'
#' @param x times where to predict
#' @param fit fitted curve model parameters
#' @export

curve_predict  <- function(x, model_fit) {
  model <- attr(model_fit, "model")
  modelf <- get(paste0("model_", model))
  shift <- attr(model_fit, "nugget")
  y <- modelf(x, model_fit)
  y <- y + shift
  y
}


