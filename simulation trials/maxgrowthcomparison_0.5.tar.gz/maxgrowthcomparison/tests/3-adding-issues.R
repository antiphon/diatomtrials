# Check the problems

devtools::load_all(".")

x <- seq(0, 10, l = 20)
params <- c(2, 3, 4)

y <- model_gompertz(x, params)
obs <- cbind(x,y)

par(mfrow=c(3,2))

for(p in problems) {
  plot(obs, ylim = range(y), xlim = range(x), type="l")
  points(p(obs, at = 7, sigma = .15, by = 3, rate=1, log = TRUE), col=2)
}


# Check the add noise options

# plot(obs)
# plot(add_noise(obs, truncate = FALSE))
# plot(add_noise(obs, truncate = FALSE, log = TRUE))
# plot(add_noise(obs, truncate = TRUE, log = TRUE))
