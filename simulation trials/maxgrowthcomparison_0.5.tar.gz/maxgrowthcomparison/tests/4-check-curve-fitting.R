# Check fitting

devtools::load_all(".")

x <- seq(0, 10, l = 20)
params <- c(2, 3, 4)
y <- model_logistic(x, params)
true <- cbind(x,y)

obs <- add_noise(true, sigma = 0.2)

# true and correct model
if(0) {
  f1 <- curve_fit(obs[,1], obs[,2], model = "logistic")
  y1 <- model_logistic(x, f1)
  plot(true, type="l"); lines(x,y1, col=3);points(obs)
}

# peleg, no truncation
if(0) {
  f1 <- curve_fit(obs[,1], obs[,2], model = "peleg")
  y1 <- model_peleg(x, f1)
  plot(true, type="l"); lines(x,y1, col=3);points(obs)
}


# peleg, truncation
if(0) {
  obst <- obs#add_crash(obs, at = 10)
  f1 <- curve_fit(obst[,1], obst[,2], model = "peleg")
  y1 <- model_peleg(x, f1)
  plot(true, type="l"); lines(x, y1, col=3);points(obst)
  # try augmentation technique
  dx <- diff(x)[1]
  obsta <- rbind( obst, cbind(max(x) + 1:5*dx, 0) )
  f2 <- curve_fit(obsta[,1], obsta[,2], model = "peleg")
  y2 <- curve_predict(x, f2)#model_peleg(x, f2)
  lines(x, y2, col=4)
  print(c(true=params[1], peleg=f1[1], aug_peleg=f2[1]))
}

# log scale fit
if(1) {
  y <- model_gompertz(x, params)
  true <- cbind(x,y)
  obs <- add_noise_laplace(true, sigma = 0.1, log = TRUE) + runif(1, 0,.5)
  plot(true, type="l", log = "", ylim  = range(-1,obs[,2]))
  points(obs)
  for(l in 0:1){
    f1 <- curve_fit(obs[,1], obs[,2], model = "baranyi", logscale = l, nugget=TRUE)
    y1 <- get(paste0("model_", attr(f1, "model")))(x, f1)
    print( sum( abs(y1-obs) )  )
    lines(x, y1, col=3+l)
  }
  legend("topleft", col = 3:4, c("nat", "log"), lty=1)
}

# nugget
if(0) {
  #set.seed(1)
  shift <- 1
  y <- model_gompertz(x, params)
  true <- cbind(x, y + shift)
  obs <- add_noise(true, sigma = 0.1, log = TRUE)
  plot(true, type="l", log = "", ylim  = range(-1, obs[,2]))
  points(obs)
  for(l in 0:1){
    f1 <- curve_fit(obs[,1], obs[,2], model = "g", logscale = l)
    y1 <- curve_predict(x, f1)
    print(c(true=shift, est=attr(f1, "nugget")))
    #print( sum( abs(log(y1+0.01)-log(obs+0.01)) )  )
    #print(rbind(NULL,f1[]))
    lines(x, y1, col=3+l)
  }
    legend("topleft", col=3:4, c("nat", "log"), lty=1)
}




