# Check curve models
devtools::load_all(".")

x <- seq(0,10, l=500)

library(dplyr)
library(ggplot2)

#ml <- names(curve_models) %>% setdiff(c("Peleg" ) )

ml <- c("Logistic", "Weibull", "MMF", "Baranyi")

y0 <- .2

par3 <- c(3, 2, 10)
par3a <- c(.2, 5, 10)# for "non" canonicals

df <- tibble()

for( mn in ml ) {
  par <- switch (mn,
    Peleg = c(par3, -1, 10),
    Richards = c(par3, .5),
    Weibull = c(par3a,   y0),
    Janoschek = c(par3a, y0),
    MMF = c(par3a, y0),
    Bertanlaffy = c(par3a[1], 0, par3a[3]),
    Baranyi = c(rate=2, lag=2, 10, y0),
    par3
  )
  y <- curve_models[[mn]](x, params = par)
  df <- df %>% bind_rows(
    tibble(x = x,
           y = y,
           ly = log(y),
           dy = c(NA, diff(y)/diff(x[1:2])),
           "dy/y" = dy/y,
    model = mn) )
}

df <- df %>% mutate(model = factor(model, levels = ml))


p <- df %>% ggplot() +
  geom_line(aes(x, y, col = model))
pl <- df %>% ggplot() +
  geom_line(aes(x, ly, col = model))
pd <- df %>% ggplot() +
  geom_line(aes(x, `dy/y`, col = model))

gridExtra::grid.arrange(p, pl+ ylim(c(-4,log(11))), pd)
