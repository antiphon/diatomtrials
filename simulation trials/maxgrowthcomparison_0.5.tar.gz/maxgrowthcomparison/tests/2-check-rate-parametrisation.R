# Check that max rate is correctly parameterised
devtools::load_all(".")
x <- seq(0, 10, l=1000)
r <- 1
for(model in curve_models){
  y <- model(x, c(r, 3, 10, .5))
  print(c(r=r, dr=max(diff(y)/diff(x)[1])))
}
