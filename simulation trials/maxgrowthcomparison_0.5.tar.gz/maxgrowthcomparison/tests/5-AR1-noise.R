# Check the AR1 noise error

devtools::load_all(".")

x <- seq(0, 10, l = 20)

params <- c(2, 3, 4)
y <- model_gompertz(x, params)
#y <- x*0
obs <- cbind(x, y)

par(mfrow=c(4,2))
for(i in 1:8) {
  plot(obs, ylim = range(y) * c(.1, 1.2), xlim = range(x), type="l")
  obsy <- add_AR1_noise(obs, sigma = .4, rho = .7, truncate = !F)
  lines(obsy, col=2, type="b", pch = 19, cex=.3)
}



# check expectations

if(1){
  v <- cbind(1:10000, 1)
  s2 <- .5
  e <- add_AR1_noise(v, log = TRUE, log1 = TRUE, sigma = sqrt(s2))
  print(est=c(mean(e[,2]), theo_if_no_centered=exp(s2/2)))
}
